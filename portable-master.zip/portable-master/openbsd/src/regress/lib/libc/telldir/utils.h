/*	$OpenBSD$	*/

/*	Written by Ingo Schwarze, 2013,  Public domain.	*/

void createfiles(int);
void delfiles(void);
