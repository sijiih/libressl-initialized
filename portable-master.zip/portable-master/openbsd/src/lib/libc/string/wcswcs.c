/*	$OpenBSD$	*/
/* $NetBSD: wcswcs.c,v 1.1 2003/03/05 20:18:17 tshiozak Exp $ */

#define WCSWCS
#include "wcsstr.c"
